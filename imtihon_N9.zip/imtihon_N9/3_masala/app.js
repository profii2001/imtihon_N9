//currying
const myFunc = () =>{
    
}