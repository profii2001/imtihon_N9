let str = "Hello, World!";
let mappedStr = "";

for (let i = 0; i < str.length; i++) {
    
    mappedStr += str[i].toUpperCase();
}

console.log(mappedStr);